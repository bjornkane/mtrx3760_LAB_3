#ifndef ORGATE_H
#define ORGATE_H

#include "LogicGates.h"

class COrGates : public CLogicGates {
public:
    COrGates();
    void DriveInput(int inputIndex, eLogicLevel level) override;
    eLogicLevel GetOutputState() const override;

protected:
    void ComputeOutput() override;
};

#endif // CORGATE_H
