#include "Circuit.h"
#include <iostream>

void Circuit::AddGate(const std::string& gateType, const std::string& gateName) {
    if (gateType == "AND") {
        gates[gateName] = new CAndGates();
    } else if (gateType == "XOR") {
        gates[gateName] = new CXORGates();
    } else if (gateType == "OR") {
        gates[gateName] = new COrGates();
    } else if (gateType == "NOT") {
        gates[gateName] = new CNotGate();
    } else if (gateType == "1BitComparator") {
        gates[gateName] = new COneBitComparator();
    } else {
        std::cerr << "Error: Unknown gate type " << gateType << std::endl;
    }
}

void Circuit::DriveGate(const std::string& gateName, int inputIndex, eLogicLevel level) {
    if (gates.find(gateName) != gates.end()) {
        std::cout << "Input Index " << inputIndex << " of " << gateName << " gate runs with logic " << static_cast<int>(level) << std::endl;
        gates[gateName]->DriveInput(inputIndex, level);
    } else {
        std::cerr << "Error: Gate " << gateName << " not found." << std::endl;
    }
}

eLogicLevel Circuit::GetGateOutput(const std::string& gateName) const {
    if (gates.find(gateName) != gates.end()) {
        return gates.at(gateName)->GetOutputState();
    } else {
        std::cerr << "Error: Gate " << gateName << " not found." << std::endl;
        return eLogicLevel::LOGIC_UNDEFINED;
    }
}

eLogicLevel Circuit::GetComparatorOutput(const std::string& gateName, const std::string& outputType) const {
    if (gates.find(gateName) != gates.end()) {
        COneBitComparator* comparator = dynamic_cast<COneBitComparator*>(gates.at(gateName));
        if (comparator) {
            if (outputType == "greater") {
                return comparator->GetGreaterOutput();
            } else if (outputType == "equal") {
                return comparator->GetEqualOutput();
            } else if (outputType == "less") {
                return comparator->GetLessOutput();
            }
        }
    }
    std::cerr << "Error: Gate " << gateName << " not found or not a comparator." << std::endl;
    return eLogicLevel::LOGIC_UNDEFINED;
}

void Circuit::AddOutputGate(const std::string& gateName) {
    outputGates.push_back(gateName);
}
